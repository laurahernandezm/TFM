# -*- coding: utf-8 -*-
"""
Laura Hernández Muñoz

Manage datasets
File structure taken from Tracking without bells and whistles (https://github.com/phil-bergmann/tracking_wo_bnw)
"""

import torch
from torch.utils.data import Dataset
from cctv_sequence import CCTVSequence

class CCTVWrapper(Dataset):

    def __init__(self, split, dataloader):

        train_sequences = ['train_1', 'train_3', 'train_4', 'train_5',
                            'train_6', 'train_7', 'train_8', 'train_9',
                            'train_10', 'train_11', 'train_12', 'train_13',
                            'train_14', 'train_15', 'train_16', 'train_17',
                            'train_18', 'train_21', 'train_22', 'train_23',
                            'train_24', 'train_26', 'train_27', 'train_28',
                            'train_29', 'train_30', 'train_31', 'train_32']

        test_sequences = ['test_1', 'test_2', 'test_3', 'test_4', 'test_5',
                            'test_6', 'test_7', 'test_8', 'test_9', 'test_10',
                            'test_11', 'test_12', 'test_13', 'test_14',
                            'test_15', 'test_16', 'test_17', 'test_18',
                            'test_19', 'test_20', 'test_21', 'test_22',
                            'test_23', 'test_24', 'test_25', 'test_26',
                            'test_27', 'test_28', 'test_29', 'test_30',
                            'test_31', 'test_32', 'test_33', 'test_34',
                            'test_35', 'test_36', 'test_37', 'test_38',
                            'test_39', 'test_40', 'test_41', 'test_42',
                            'test_43', 'test_44', 'test_45', 'test_46',
                            'test_47']

        if "train" == split:
            sequences = train_sequences
        elif "test" == split:
            sequences = test_sequences
        else:
            raise NotImplementedError("Split not available.")

        self._data = []

        for s in sequences:
            self._data.append(CCTVSequence(seq_name=s, **dataloader))

    def __len__(self):
        return len(self._data)

    def __getitem__(self, idx):
        return self._data[idx]
